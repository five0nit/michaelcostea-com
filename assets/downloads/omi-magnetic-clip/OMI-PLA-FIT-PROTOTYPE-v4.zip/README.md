# Omi magnetic carrier — compact thin-face PLA fit prototype v4

## Changes requested after v3 physical fit feedback
- Magnet bore diameter **4.30 → 5.30 mm**: +1 mm total diameter, not +1 mm per side. Magnet-height allowance unchanged.
- All four actual magnet centres **1.00 mm radially inward**: 10.250 → 9.250 mm radius. Measured from old/new exported magnet meshes, compensating the datum shift caused by thinner cap faces.
- Outer base ring **Ø37.00 → Ø29.19 mm**. Ring stays 0.35 mm inside the outer radial tips of the four socket pods. The footprint across pod-tip directions can exceed the ring diameter.
- Cap retaining face **0.96 → 0.32 mm**, confirmed as **two 0.16 mm layers** in actual G-code. No screwdriver slots: those would cut through the thin face.
- Exposed magnet opening **Ø3.00 → Ø3.50 mm**. Remaining overlap for an estimated Ø4 mm magnet is 0.25 mm radially when centred.
- Magnet face recess from the cap surface **1.06 → 0.42 mm**, including 0.10 mm internal free space. This is increased exposure, not proven magnetic strength or guaranteed direct contact.
- **15° tilt unchanged**. PLA rigid coarse-thread retention retained; surrounding male/female threads widened with the bore to preserve nominal 0.80 mm root and 1.05 mm pod walls.

**Use matching v4 body and caps. New wider threads are not interchangeable with v3.** Previous v2/v3 packages remain unchanged.

## Status
Digitally built, raw STL/BRep validated, CAD seated and screw-motion collisions checked, sliced and actual toolpaths inspected. Revised parts have NOT been physically printed or fit-tested. No print job sent. User reported earlier holes too tight; exact magnet dimensions remain unmeasured. Four salvaged retail-box magnets, estimated Ø4 × 3 mm, remain the reference geometry.

## Print the small fit test first
Open `OMI_PLA_FIT_TEST.3mf` for **Bambu A1 mini, 0.4 mm nozzle, PLA, Textured PEI** only. This is the prepared verification profile, not a confirmation of printer ownership. Other printer: import STL and reslice for that exact printer. To keep the cap face exactly two layers, use **0.16 mm initial AND subsequent layer heights**. Caps print flange/face-down, with threaded barrels up. No supports or brim. Prepared settings: four requested walls, six top/bottom shells, 25% gyroid, 220°C print temperature / 65°C bed. Narrow walls receive the available paths. Arc fitting is off for faithful diagnostic toolpath inspection.

Fit plate = one cropped, real-angle socket + one matching thin-face cap. Slicer estimate: **12m 52s including preparation**, 5m 11s model printing, **0.53 g PLA**. These are estimates, not measured printing results.

1. Print the small v4 fit plate in PLA. Leave the working cardboard holder intact.
2. Try the empty cap gently. Remove loose stringing; stop if threads bind or the thin face deforms. Do not force a tight thread.
3. Measure the actual magnet and test the new Ø5.30 mm bore before printing all parts. The reference magnet remains estimated Ø4 × 3 mm.
4. Insert magnet into the cap's open barrel from behind the face, with chosen outward pole toward the Ø3.50 mm opening. Thread loaded cap into socket gently by friction on the outer rim; a rubber-tipped tool may help. There is NO screwdriver slot. Do not press a blade onto the thin inner retaining edge or across the exposed magnet.
5. Check the two-layer lip remains intact and the magnet cannot escape the front opening or rear Ø1.80 mm release hole. Test shifted/off-centre loading as well as centred loading: the enlarged bore permits lateral play. Check for loosening, excessive rattle or lip flexing over repeated handling. CAD overlap alone is not a pull-out-strength test.
6. Only after coupon passes, print full body and matching caps. Reproduce the working cardboard holder's magnet polarity. Test Omi attachment through the intended shirt over a soft surface. Keep original holder until placement and holding strength are proven.

## Dimensions and assembly
Rounded base thickness 1.60 mm, ring diameter 29.19 mm, body X/Y extent 29.19 mm, body height 6.18 mm. Assembled height including caps: 6.33 mm (v3: 6.68 mm). Pockets preserve at least 1.00 mm floor excluding intentional release holes. Nominal thread pitch 1.40 mm, engagement two turns, 0.20 mm radial and 0.12 mm axial thread clearance. Aperture overlap is reduced versus v3; physical cap strength, print tolerance and holding force remain acceptance tests.

Both slices contain 38 executable layers, ending at Z6.08 mm. The slicer initially declares 39, then explicitly marks layer 39 empty in `slice_info.config`: its remaining inclined outer pod-tip crescent is under 0.25 mm wide at the slice plane (below the 0.4 mm nozzle's retained feature size). Thus the body tip is quantized about 0.10 mm below CAD. Cap-face layers 1 and 2 and all continuous root-wall paths remain present. Evidence records this distinction rather than claiming 39 printed layers. Existing-profile slicer notices include bed-temperature and traditional-timelapse warnings; no print has been dispatched.

`OMI_PLA_PROTOTYPE.3mf`: one body + four retainers + one spare/test retainer + one coupon = seven printed parts. Estimate **28m 9s including preparation**, **2.65 g PLA**. Import combined STL as one plate/object preserving component placement; do not auto-orient threaded parts.

## Files
- `models/carrier_body.stl`: one v4 body.
- `models/retainer_print_4.stl`: ONE retainer; print four for carrier (filename denotes quantity needed, not four embedded parts).
- `models/fit_coupon.stl`: cropped actual pocket, same tilt/bed height/overhangs.
- `models/fit_test_plate.stl`, `models/prototype_plate.stl`: laid-out print plates.
- `cad/*.step`: editable CAD; `assembly_reference_not_for_print.step` includes reference magnets. Never print the assembly/reference magnets.
- `source/build_prototype.py`: parametric source, CadQuery 2.8.0.
- `evidence/preflight.json`, `evidence/revision-comparison.json`: geometry and real mesh measurements.
- `evidence/slicer-readback.json`, `evidence/cap-layer-verification.json`: embedded slicer settings, actual first/second/third layer bore transition.
- `OMI_PLA_PREVIEW.png`: assembled/exploded CAD; lighter caps distinguish parts, not required filament colours.
- `OMI_PLA_REVISION_COMPARISON.png`: old/new actual CAD at same camera and scale.
- `OMI_PLA_TOOLPATHS.png`: actual selected fit-plate extrusion paths.

Rebuild CAD from source directory:
```
uv run --no-project --with cadquery==2.8.0 --with trimesh --with networkx python build_prototype.py
```

Source reference: https://github.com/BasedHardware/omi and https://docs.omi.me/doc/hardware/consumer/mechanical . Based Hardware MIT notice included. Local canonical generator/selected CadQuery library reused; this is a bounded fit edit, not a new build-base selection. Existing project discovery receipts retained; no dependencies installed or new candidates executed for this revision. No app, gateway or printer settings changed.
