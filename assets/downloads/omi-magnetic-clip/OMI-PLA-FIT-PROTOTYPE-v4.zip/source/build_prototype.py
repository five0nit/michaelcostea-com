#!/usr/bin/env python3
"""PLA Omi magnet carrier fit prototype. mm. No physical-fit/force claim.
Run: uv run --no-project --with cadquery==2.8.0 --with trimesh --with networkx python build_prototype.py
"""
from pathlib import Path
import argparse, json, math
import cadquery as cq
import trimesh

ROOT = Path(__file__).resolve().parent
P = dict(magnet_diameter=4.0, magnet_height=3.0, pocket_diameter=5.30,
         tilt_deg=15.0, phase_deg=45.0, fabric_gap=0.50,
         radial_inset=1.0, placement_reference_cap_lip=0.96, ring_tip_inset=0.35,
         wrapper_major=7.75, wrapper_minor=6.60, wrapper_center_z=12.0,
         base_radius=18.5, base_thickness=1.60, center_opening_radius=6.0,
         pod_radius=5.20, floor=1.0, axial_clearance=0.20,
         cap_lip=0.32, cap_aperture_diameter=3.5, cap_flange_radius=4.35,
         stem_outer=3.45, stem_length=2.80, thread_pitch=1.40,
         cap_bore_radius=3.65, thread_crest_radius=3.95,
         thread_radial_clearance=0.20, thread_axial_clearance=0.12,
         material='PLA', retention='rigid_coarse_thread_no_snap_fingers')

def cyl(r, h, z=0):
    return cq.Workplane('XY').workplane(offset=z).circle(r).extrude(h).val()

def ring_profile(points):
    return cq.Workplane('XZ').polyline(points).close().revolve(360,(0,0),(0,1)).val()

def thread(p, female=False):
    lipz=p['floor']+p['magnet_height']+p['axial_clearance']; stemz=lipz-p['stem_length']
    dr=p['thread_radial_clearance'] if female else 0
    dz=p['thread_axial_clearance'] if female else 0
    r=p['stem_outer']-0.02+dr; crest=p['thread_crest_radius']+dr
    profile=[(r,-0.50-dz),(crest,-0.08-dz),(crest,0.08+dz),(r,0.50+dz)]
    start=stemz-p['thread_pitch']
    wire=cq.Wire.makeHelix(p['thread_pitch'],p['stem_length']+3*p['thread_pitch'],p['stem_outer'])
    return cq.Workplane('XZ').polyline(profile).close().sweep(wire,isFrenet=True).val().translate((0,0,start))

def capsule(p, diameter=None):
    floor=p['floor']; t=p['magnet_height']; lipz=floor+t+p['axial_clearance']
    stemz=lipz-p['stem_length']; d=diameter or p['pocket_diameter']
    s=cq.Workplane('XY').circle(p['pod_radius']).extrude(lipz).edges('>Z').fillet(0.25).val()
    # Bore extends beyond the full sweep, avoiding end-face trim ambiguities.
    cuts=cyl(d/2,20,floor)
    cuts=cuts.fuse(cyl(p['cap_bore_radius'],20,stemz-0.12))
    helix=thread(p,True).intersect(cyl(p['pod_radius'],lipz+3,stemz-0.12))
    cuts=cuts.fuse(helix)
    cuts=cuts.fuse(cyl(0.9,floor+3,-2))
    return s, cuts

def cap(p):
    lipz=p['floor']+p['magnet_height']+p['axial_clearance']; stemz=lipz-p['stem_length']
    # Continuous rigid PLA barrel; 1.4 mm pitch coarse thread, no flexure.
    # Trim the swept helix FIRST, then union the continuous core. Unioning an
    # overlength helix before trimming can yield a valid but incomplete barrel.
    threadpart=thread(p).intersect(cyl(p['pod_radius'],p['stem_length'],stemz))
    stem=cyl(p['stem_outer'],p['stem_length'],stemz).fuse(threadpart)
    stem=stem.cut(cyl(p['pocket_diameter']/2,p['stem_length']+2,stemz-1))
    flange=cyl(p['cap_flange_radius'],p['cap_lip'],lipz).cut(cyl(p['cap_aperture_diameter']/2,p['cap_lip']+2,lipz-1))
    # Two full 0.16 mm layers. No screwdriver recess through this thin lip.
    result=stem.fuse(flange).clean()
    expected_core=cyl(p['stem_outer']-0.01,p['stem_length']-0.02,stemz+0.01).cut(cyl(p['pocket_diameter']/2+0.01,p['stem_length']+2,stemz-1))
    assert expected_core.cut(result).Volume()<1e-6,'Missing continuous retainer root wall'
    return result

def placement(p, i):
    a=math.radians(p['tilt_deg']); phi=p['phase_deg']+90*i
    # Keep actual magnet centres exactly 1 mm inward from v3. Compensate
    # the radial datum shift that otherwise accompanies the thinner cap lip.
    radius=p['wrapper_major']+(p['wrapper_minor']+p['fabric_gap'])*math.sin(a)-p['radial_inset']+(p['placement_reference_cap_lip']-p['cap_lip'])*math.sin(a)
    topz=p['wrapper_center_z']-(p['wrapper_minor']+p['fabric_gap'])*math.cos(a)
    length=p['floor']+p['magnet_height']+p['axial_clearance']+p['cap_lip']
    off=(radius+length*math.sin(a),0,topz-length*math.cos(a))
    def place(s):
        return s.rotate((0,0,0),(0,1,0),-p['tilt_deg']).translate(off).rotate((0,0,0),(0,0,1),phi)
    magnet_center_radius=off[0]-(p['floor']+p['magnet_height']/2+0.10)*math.sin(a)
    return place, dict(azimuth_deg=phi,face_center_radius=radius,face_center_z=topz,tilt_deg=p['tilt_deg'],magnet_center_radius=magnet_center_radius)

def export(s,name,out,report,printable=True):
    assert s.isValid(),f'{name}: invalid BRep'
    assert len(s.Solids())==1,f'{name}: disconnected BRep'
    cq.exporters.export(s,str(out/(name+'.step')))
    # Fresh STEP topology avoids stale OCCT triangulation at trimmed helix seams.
    # 0.04 mm chordal tolerance remains one tenth of the target nozzle diameter.
    fresh=cq.importers.importStep(str(out/(name+'.step'))).val()
    cq.exporters.export(fresh,str(out/(name+'.stl')),tolerance=0.04,angularTolerance=0.15)
    m=trimesh.load_mesh(out/(name+'.stl'))
    checks=dict(brep_valid=s.isValid(),brep_solids=len(s.Solids()),watertight=bool(m.is_watertight),
                winding_consistent=bool(m.is_winding_consistent),mesh_components=len(m.split(only_watertight=False,repair=False)),
                volume_mm3=float(m.volume),bounds_mm=m.bounds.tolist(),extent_mm=m.extents.tolist(),faces=len(m.faces))
    assert checks['watertight'] and checks['winding_consistent'] and checks['mesh_components']==1 and m.volume>0,checks
    if printable: assert abs(float(m.bounds[0,2]))<1e-4,(name,m.bounds)
    report['parts'][name]=checks


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tilt',type=float,default=P['tilt_deg']); ap.add_argument('--out',default='prototype-pla-v4'); args=ap.parse_args()
    p=P.copy();p['tilt_deg']=args.tilt
    if not 15<=args.tilt<=40: raise ValueError('Current structure validated only for bounded prototype tilt range 15–40; revalidate every generated build.')
    # Preserve >=1 mm of material below the pocket/threads as flatter placement
    # moves the contact point inward/downward. Drain intentionally excluded.
    a=math.radians(p['tilt_deg'])
    lipz=p['floor']+p['magnet_height']+p['axial_clearance']
    stemz=lipz-p['stem_length']
    origin_z=p['wrapper_center_z']-(p['wrapper_minor']+p['fabric_gap']+lipz+p['cap_lip'])*math.cos(a)
    lowest=origin_z+min(p['floor']*math.cos(a)-p['pocket_diameter']/2*math.sin(a),
        (stemz-0.12)*math.cos(a)-(p['thread_crest_radius']+p['thread_radial_clearance'])*math.sin(a))
    p['wrapper_center_z']+=max(0,1.0-lowest)
    p['cavity_floor_z_lower_bound']=lowest+max(0,1.0-lowest)
    # Keep the base ring inside the actual outer radial tip of the socket pod.
    pod,cut=capsule(p);c=cap(p)
    place0,_=placement(p,0)
    radial_pod=place0(pod).rotate((0,0,0),(0,0,1),-p['phase_deg'])
    p['pod_outer_radial_tip']=radial_pod.BoundingBox().xmax
    p['base_radius']=p['pod_outer_radial_tip']-p['ring_tip_inset']
    assert p['base_radius']>p['center_opening_radius']+2
    out=ROOT/args.out;out.mkdir(exist_ok=True)
    report={'parameters':p,'parts':{},'geometry_checks':{},'status':'DIGITAL_FIT_PROTOTYPE_NOT_PHYSICALLY_VALIDATED'}
    base=cq.Workplane('XY').circle(p['base_radius']).circle(p['center_opening_radius']).extrude(p['base_thickness']).edges().fillet(0.35).val()
    body=base; cutters=[]; caps=[]; mags=[]; locations=[]
    for i in range(4):
        place,loc=placement(p,i);body=body.fuse(place(pod));cutters.append(place(cut));caps.append(place(c));locations.append(loc)
        mags.append(place(cyl(p['magnet_diameter']/2,p['magnet_height'],p['floor']+0.10)))
    # Trim small capsule feet to the common print bed before cutting all cavities.
    body=body.intersect(cq.Workplane('XY').box(100,100,100,centered=(True,True,False)).val())
    for tool in cutters: body=body.cut(tool)
    body=body.clean()
    lipz=p['floor']+p['magnet_height']+p['axial_clearance']
    capprint=c.rotate((0,0,0),(1,0,0),180).translate((0,0,lipz+p['cap_lip']))
    export(body,'carrier_body',out,report)
    export(capprint,'retainer_print_4',out,report)
    # Analytic vertical socket for local thread-motion checks.
    coupon=pod.cut(cut).clean()
    # Print coupon is cropped from the ACTUAL carrier, preserving its tilted
    # hole, bed height, thread overhang and first-layer geometry, not reoriented.
    a=math.radians(p['tilt_deg']);phi=math.radians(p['phase_deg'])
    radial=locations[0]['face_center_radius']+math.sin(a)*(lipz+p['cap_lip'])
    cx,cy=radial*math.cos(phi),radial*math.sin(phi)
    printcoupon=body.intersect(cyl(6.5,20).translate((cx,cy,0))).translate((-cx,-cy,0)).clean()
    export(printcoupon,'fit_coupon',out,report)
    # Real multipart STEP assembly; magnets are reference-only, not print parts.
    assembly=cq.Assembly(name='OMI_MAGNET_CARRIER_FIT_PROTOTYPE')
    assembly.add(body,name='carrier_body',color=cq.Color(0.07,0.10,0.12))
    for i,(cp,mag) in enumerate(zip(caps,mags)):
        assembly.add(cp,name=f'retainer_{i+1}',color=cq.Color(0.16,0.21,0.23))
        assembly.add(mag,name=f'REFERENCE_ONLY_magnet_{i+1}',color=cq.Color(0.75,0.77,0.8))
    assembly.export(str(out/'assembly_reference_not_for_print.step'))
    # Explicit seated collision checks and threaded assembly motion checks.
    g=report['geometry_checks'];g['locations']=locations
    g['ring_inside_pod_tips_mm']=p['pod_outer_radial_tip']-p['base_radius']
    g['cap_face_thickness_mm']=p['cap_lip']
    g['cap_aperture_diameter_mm']=p['cap_aperture_diameter']
    g['body_cap_intersections_mm3']=[body.intersect(x).Volume() for x in caps]
    g['body_magnet_intersections_mm3']=[body.intersect(x).Volume() for x in mags]
    g['cap_magnet_intersections_mm3']=[x.intersect(y).Volume() for x,y in zip(caps,mags)]
    assert max(g['body_cap_intersections_mm3']+g['body_magnet_intersections_mm3']+g['cap_magnet_intersections_mm3'])<1e-6,g
    g['retaining_overlap_radius_mm']=(p['magnet_diameter']-p['cap_aperture_diameter'])/2
    g['thread_radial_clearance_mm']=p['thread_radial_clearance']
    g['thread_axial_clearance_mm']=p['thread_axial_clearance']
    g['thread_engagement_turns']=p['stem_length']/p['thread_pitch']
    g['stem_nominal_wall_mm']=p['stem_outer']-p['pocket_diameter']/2
    g['pod_thread_wall_mm']=p['pod_radius']-p['thread_crest_radius']-p['thread_radial_clearance']
    assert g['stem_nominal_wall_mm']>=0.79,'Enlarged bore thinned PLA root wall'
    assert g['pod_thread_wall_mm']>=1.04,'Enlarged female thread thinned pod wall'
    # Gauge probes the enlarged magnet bore, not the larger surrounding thread.
    g['magnet_bore_probe_diameter_mm']=p['pocket_diameter']-0.02
    probe=cyl(g['magnet_bore_probe_diameter_mm']/2,p['magnet_height'],p['floor']+0.10)
    g['magnet_bore_probe_intersections_mm3']={'cap':c.intersect(probe).Volume(),'socket':coupon.intersect(probe).Volume()}
    assert max(g['magnet_bore_probe_intersections_mm3'].values())<1e-6,g
    g['thread_motion_collision_mm3']={}
    for degrees in (0,90,180,270,360,540,720,900):
        moved=c.rotate((0,0,0),(0,0,1),degrees).translate((0,0,p['thread_pitch']*degrees/360))
        overlap=coupon.intersect(moved).Volume()
        g['thread_motion_collision_mm3'][str(degrees)]=overlap
        assert overlap<1e-5,(degrees,overlap)
    g['magnet_face_recess_from_cap_surface_mm']=p['cap_lip']+0.10
    # Clean analytic torus from inspected wrapper values. It is a surface-envelope
    # reference, not a claim that the complete shipped device is this torus.
    torus=cq.Solid.makeTorus(p['wrapper_major'],p['wrapper_minor']).translate((0,0,p['wrapper_center_z']))
    g['wrapper_torus_intersection_mm3']=body.intersect(torus).Volume()+sum(x.intersect(torus).Volume() for x in caps)
    assert g['wrapper_torus_intersection_mm3']<1e-6,g
    # CAD transform references for preview; not added to printable export list.
    cq.exporters.export(torus,str(out/'reference_torus.stl')),cq.exporters.export(cq.Compound.makeCompound(caps),str(out/'reference_caps_seated.stl'))
    cq.exporters.export(cq.Compound.makeCompound(mags),str(out/'reference_magnets.stl'))
    exploded=[]
    for i in range(4):
        place,_=placement(p,i); exploded.append(place(c.translate((0,0,3.0))))
    cq.exporters.export(cq.Compound.makeCompound(exploded),str(out/'reference_caps_exploded.stl'))
    # Lay out only exact, already-validated meshes; no new CAD tessellation here.
    def mesh_at(name,x,y):
        m=trimesh.load_mesh(out/(name+'.stl'));m.apply_translation((x,y,0));return m
    plate=[mesh_at('carrier_body',-22,0),mesh_at('fit_coupon',12,-11)]
    for x,y in [(11,3),(21,3),(11,13),(21,13),(23,-11)]:plate.append(mesh_at('retainer_print_4',x,y))
    trimesh.util.concatenate(plate).export(out/'prototype_plate.stl')
    trimesh.util.concatenate([mesh_at('fit_coupon',0,0),mesh_at('retainer_print_4',13,0)]).export(out/'fit_test_plate.stl')
    report['plate_expected_components']=7
    m=trimesh.load_mesh(out/'prototype_plate.stl');report['plate_components']=len(m.split(only_watertight=False,repair=False));assert report['plate_components']==7 and m.is_watertight and m.is_winding_consistent
    (out/'preflight.json').write_text(json.dumps(report,indent=2))
    (out/'parameters.json').write_text(json.dumps(p,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
