import bpy,math
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parent/'prototype-pla-v5'
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH'
s.render.resolution_x=1400;s.render.resolution_y=1050;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG'
s.display.shading.light='STUDIO';s.display.shading.studiolight_rotate_z=.5
s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=True
s.display.shading.show_cavity=True;s.display.shading.cavity_type='BOTH'
s.display.shading.curvature_ridge_factor=1.5;s.display.shading.curvature_valley_factor=1.1
s.display.shading.background_type='WORLD';s.world.color=(.88,.9,.92)
s.display.shading.show_specular_highlight=True
objects=[]
def load(name,color):
 bpy.ops.wm.stl_import(filepath=str(ROOT/(name+'.stl')));o=bpy.context.object
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);o.data.materials.append(m);objects.append(o);return o
body=load('carrier_body',(.07,.09,.11));cap=load('reference_caps_seated',(.21,.27,.30));mag=load('reference_magnets',(.67,.70,.73));ex=load('reference_caps_exploded',(.21,.27,.30))
coupon=load('fit_test_plate',(.14,.20,.23))
sect=[load('section_socket',(.10,.14,.18)),load('section_cap',(.27,.36,.40)),load('section_magnet',(.72,.74,.76))]
bpy.ops.object.camera_add();cam=bpy.context.object;s.camera=cam;cam.data.type='ORTHO'
def render(name,visible,position,target,scale):
 for o in objects:o.hide_render=o not in visible
 cam.location=position;cam.data.ortho_scale=scale
 cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
 s.render.filepath=str(ROOT/(name+'.png'));bpy.ops.render.render(write_still=True)
render('front',[body,cap,mag],(43,-60,61),(0,0,3),43)
render('rear',[body,cap,mag],(43,-60,-61),(0,0,3),43)
render('rear-exploded',[body,ex,mag],(43,-60,-61),(0,0,1),46)
render('side',[body,cap,mag],(50,-50,18),(0,0,3),43)
render('section',sect,(0,-30,6),(0,0,2.2),12)
render('coupon',[coupon],(21,-25,23),(6,0,2),29)
