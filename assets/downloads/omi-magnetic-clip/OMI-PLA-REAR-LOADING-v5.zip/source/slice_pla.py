"""Digital slicing only: no network/printer dispatch. Existing Bambu installation."""
from pathlib import Path
import argparse, json, shutil, subprocess, sys, zipfile
parser=argparse.ArgumentParser();parser.add_argument('--version',choices=['v4','v5'],default='v4');args=parser.parse_args()
ROOT=Path(__file__).resolve().parent/('prototype-pla-'+args.version); S=ROOT/'slicer'
STAGE=Path('/mnt/c/Users/coste/AppData/Local/Temp')/('omi-clip-pla-'+args.version);STAGE.mkdir(parents=True,exist_ok=True)
process=json.loads((S/'process.json').read_text())
process.update({'name':'OMI PLA 0.16mm rigid threaded prototype','layer_height':'0.16','initial_layer_print_height':'0.16','wall_loops':'4','top_shell_layers':'6','bottom_shell_layers':'6','sparse_infill_density':'25%','sparse_infill_pattern':'gyroid','enable_support':'0','enable_arc_fitting':'0','brim_type':'no_brim','elefant_foot_compensation':'0.10','outer_wall_speed':'30','inner_wall_speed':'45','initial_layer_speed':'20','curr_bed_type':'Textured PEI Plate'})
(S/'process.json').write_text(json.dumps(process,indent=2))
filament=json.loads((S/'filament.json').read_text());filament['filament_colour']=['#20262C'];(S/'filament.json').write_text(json.dumps(filament,indent=2))
for n in ['machine','process','filament']:shutil.copy2(S/(n+'.json'),STAGE/(n+'.json'))
def win(p):return subprocess.check_output(['wslpath','-w',str(p)],text=True).strip()
receipts=[]
for source,title in [('fit_test_plate.stl','OMI_PLA_FIT_TEST'),('prototype_plate.stl','OMI_PLA_PROTOTYPE')]:
    shutil.copy2(ROOT/source,STAGE/source)
    out=STAGE/title;out.mkdir(exist_ok=True)
    cmd=['/mnt/c/Program Files/Bambu Studio/bambu-studio.exe','--load-settings',win(STAGE/'machine.json')+';'+win(STAGE/'process.json'),'--load-filaments',win(STAGE/'filament.json'),'--arrange','1','--orient','0','--slice','0','--export-3mf',title+'.3mf','--outputdir',win(out),win(STAGE/source)]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    (S/(title+'.log')).write_text(r.stdout+'\n'+r.stderr)
    print(title,'exit',r.returncode, r.stdout[-1600:],r.stderr[-700:])
    receipt={'name':title,'exit_code':r.returncode,'command':cmd,'artifacts':[]}
    for p in out.rglob('*'):
        if p.is_file():
            target=S/title/p.relative_to(out);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);receipt['artifacts'].append(str(target.relative_to(ROOT)))
            if p.suffix=='.3mf':
                with zipfile.ZipFile(p) as z:
                    receipt['gcode_entries']=[x for x in z.namelist() if x.endswith('.gcode')]
                    for x in receipt['gcode_entries']:
                        (target.parent/Path(x).name).write_bytes(z.read(x))
    receipts.append(receipt)
    (S/'slicing-receipts.json').write_text(json.dumps(receipts,indent=2))
    assert r.returncode==0 and receipt.get('gcode_entries'),receipt
