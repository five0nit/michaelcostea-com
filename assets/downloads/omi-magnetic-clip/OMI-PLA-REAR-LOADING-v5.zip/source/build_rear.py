#!/usr/bin/env python3
"""v5: integral thin contact lip, rear-loading rigid PLA screw cups. mm.
Run via pinned CadQuery2.8.0; no printer dispatch. Physical strength untested.
"""
from pathlib import Path
import json, math, shutil
import cadquery as cq
import trimesh
from build_prototype import cyl, thread, placement, export
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'prototype-pla-v5'

def make_parts(p):
    # Keep v4 magnet datum z=1.10..4.10; integral lip starts 0.05 above it.
    # Head on rear z=.04..1.00; two-turn hollow barrel z=1.00..3.80.
    tp={**p,'floor':0.60}
    stemz=1.0; endz=3.8
    male=thread(tp).intersect(cyl(p['pod_radius'],endz-stemz,stemz))
    stem=cyl(p['stem_outer'],endz-stemz,stemz).fuse(male)
    stem=stem.cut(cyl(p['pocket_diameter']/2,5,stemz))
    head=cyl(p['cap_flange_radius'],p['rear_head_thickness'],stemz-p['rear_head_thickness'])
    cap=head.fuse(stem)
    # Rear-facing screwdriver recess stops 0.64mm before magnet cavity.
    driver=cq.Workplane('XY').box(6.2,0.80,0.32,centered=(True,True,False)).val().translate((0,0,stemz-p['rear_head_thickness']))
    cap=cap.cut(driver).clean()
    core=cyl(p['stem_outer']-.01,2.78,1.01).cut(cyl(p['pocket_diameter']/2+.01,4,0))
    assert core.cut(cap).Volume()<1e-6,'Incomplete cap root'
    front=4.10+p['front_gap']+p['front_lip']
    pod=cyl(p['pod_radius'],front-stemz,stemz)
    # Aperture goes through front; magnet bore stops at inner lip surface.
    cuts=cyl(p['front_aperture']/2,30,-20)
    cuts=cuts.fuse(cyl(p['pocket_diameter']/2,20+front-p['front_lip'],-20))
    cuts=cuts.fuse(cyl(p['cap_bore_radius'],20+endz+.12,-20))
    female=thread(tp,True).intersect(cyl(p['pod_radius'],20+endz+.12,-20))
    cuts=cuts.fuse(female)
    # Rear head/tool recess cuts through base too; head seats at z=1.00.
    cuts=cuts.fuse(cyl(p['cap_flange_radius']+.20,21.0,-20))
    return pod,cuts,cap

def main():
    OUT.mkdir(exist_ok=True)
    old=json.loads((ROOT/'prototype-pla-v4/preflight.json').read_text())
    p=old['parameters'].copy()
    p.update(front_lip=.32,front_gap=.05,front_aperture=3.50,rear_head_thickness=.96,retention='rear_loading_threaded_cup_integral_front_lip',version=5)
    pod,cut,c=make_parts(p)
    place0,_=placement(p,0)
    # Keep rear head inside body envelope, with 0.25mm clearance above base plane.
    lift=max(0,.25-place0(c).BoundingBox().zmin)
    p['wrapper_center_z']+=lift
    p['rear_architecture_lift_mm']=lift
    place0,_=placement(p,0)
    radial_pod=place0(pod).rotate((0,0,0),(0,0,1),-p['phase_deg'])
    p['pod_outer_radial_tip']=radial_pod.BoundingBox().xmax
    p['base_radius']=min(old['parameters']['base_radius'],p['pod_outer_radial_tip']-.35)
    report={'parameters':p,'parts':{},'geometry_checks':{},'status':'DIGITAL_FIT_PROTOTYPE_NOT_PHYSICALLY_VALIDATED'}
    body=cq.Workplane('XY').circle(p['base_radius']).circle(p['center_opening_radius']).extrude(p['base_thickness']).edges().fillet(.35).val()
    caps=[];mags=[];locations=[];cutters=[];tools=[]
    for i in range(4):
        place,loc=placement(p,i)
        body=body.fuse(place(pod));cutters.append(place(cut));caps.append(place(c));locations.append(loc)
        mags.append(place(cyl(p['magnet_diameter']/2,p['magnet_height'],1.10)))
        tools.append(place(cyl(3.1,10,-10)))
    for tool in cutters:body=body.cut(tool)
    body=body.clean()
    assert body.BoundingBox().zmin>=-1e-6
    capprint=c.translate((0,0,p['rear_head_thickness']-1))
    export(body,'carrier_body',OUT,report)
    export(capprint,'rear_cap_print_4',OUT,report)
    # Faithful crop retains actual bed, tilt, thread and front-overhang behavior.
    a=math.radians(p['tilt_deg']);phi=math.radians(p['phase_deg'])
    radial=locations[0]['face_center_radius']+math.sin(a)*(p['floor']+p['magnet_height']+p['axial_clearance']+p['cap_lip'])
    cx,cy=radial*math.cos(phi),radial*math.sin(phi)
    printcoupon=body.intersect(cyl(6.5,20).translate((cx,cy,0))).translate((-cx,-cy,0)).clean()
    export(printcoupon,'fit_coupon',OUT,report)
    assembly=cq.Assembly(name='OMI_REAR_LOADING_PLA_V5')
    assembly.add(body,name='carrier_body',color=cq.Color(.07,.1,.12))
    for i,(cap,mag) in enumerate(zip(caps,mags)):
        assembly.add(cap,name=f'rear_cap_{i+1}',color=cq.Color(.18,.24,.27))
        assembly.add(mag,name=f'REFERENCE_ONLY_magnet_{i+1}',color=cq.Color(.75,.77,.8))
    assembly.export(str(OUT/'assembly_reference_not_for_print.step'))
    g=report['geometry_checks'];g['locations']=locations
    g['front_lip_normal_thickness_mm']=p['front_lip'];g['front_aperture_mm']=p['front_aperture']
    g['front_face_recess_mm']=p['front_lip']+p['front_gap']
    g['retaining_overlap_if_centered_mm']=(p['magnet_diameter']-p['front_aperture'])/2
    g['ring_inside_pod_tips_mm']=p['pod_outer_radial_tip']-p['base_radius']
    g['cap_root_wall_mm']=p['stem_outer']-p['pocket_diameter']/2
    g['pod_thread_wall_mm']=p['pod_radius']-p['thread_crest_radius']-p['thread_radial_clearance']
    g['thread_engagement_turns']=p['stem_length']/p['thread_pitch']
    g['body_cap_intersections_mm3']=[body.intersect(x).Volume() for x in caps]
    g['body_magnet_intersections_mm3']=[body.intersect(x).Volume() for x in mags]
    g['cap_magnet_intersections_mm3']=[x.intersect(y).Volume() for x,y in zip(caps,mags)]
    assert max(g['body_cap_intersections_mm3']+g['body_magnet_intersections_mm3']+g['cap_magnet_intersections_mm3'])<1e-6,g
    # Test real assembled body, not only analytic isolated socket.
    g['rear_thread_motion_collision_mm3']={}
    g['loaded_magnet_rear_removal_collision_mm3']={}
    for angle in (0,90,180,270,360,540,720,900):
        moved=c.rotate((0,0,0),(0,0,1),-angle).translate((0,0,-p['thread_pitch']*angle/360))
        volume=body.intersect(place0(moved)).Volume()
        g['rear_thread_motion_collision_mm3'][str(angle)]=volume
        assert volume<1e-5,(angle,volume)
        mag=cyl(p['magnet_diameter']/2,p['magnet_height'],1.10-p['thread_pitch']*angle/360)
        v=body.intersect(place0(mag)).Volume();g['loaded_magnet_rear_removal_collision_mm3'][str(angle)]=v
        assert v<1e-5,(angle,v)
    probe=cyl((p['pocket_diameter']-.02)/2,3.0,1.1)
    g['bore_probe_diameter_mm']=p['pocket_diameter']-.02
    g['bore_probe_intersections_mm3']={'body':body.intersect(place0(probe)).Volume(),'cap':c.intersect(probe).Volume()}
    assert max(g['bore_probe_intersections_mm3'].values())<1e-6
    g['rear_tool_access_collision_mm3']=[body.intersect(x).Volume() for x in tools]
    assert max(g['rear_tool_access_collision_mm3'])<1e-6
    torus=cq.Solid.makeTorus(p['wrapper_major'],p['wrapper_minor']).translate((0,0,p['wrapper_center_z']))
    g['reference_envelope_collision_mm3']=body.intersect(torus).Volume()+sum(x.intersect(torus).Volume() for x in caps)
    assert g['reference_envelope_collision_mm3']<1e-6
    g['magnet_center_radial_change_from_v4_mm']=[loc['magnet_center_radius']-prev['magnet_center_radius'] for loc,prev in zip(locations,old['geometry_checks']['locations'])]
    assert max(abs(x) for x in g['magnet_center_radial_change_from_v4_mm'])<1e-8
    g['lowest_seated_rear_head_z_mm']=min(x.BoundingBox().zmin for x in caps)
    for name,shape in [('reference_torus',torus),('reference_caps_seated',cq.Compound.makeCompound(caps)),('reference_magnets',cq.Compound.makeCompound(mags))]:
        cq.exporters.export(shape,str(OUT/(name+'.stl')))
    exploded=[placement(p,i)[0](c.translate((0,0,-4))) for i in range(4)]
    cq.exporters.export(cq.Compound.makeCompound(exploded),str(OUT/'reference_caps_exploded.stl'))
    # Section through analytic socket: rear is bottom, contact side top.
    sectionbox=cq.Workplane('XY').box(24,12,24,centered=(True,False,True)).val()
    for name,shape in [('section_socket',pod.cut(cut)),('section_cap',c),('section_magnet',cyl(2,3,1.1))]:
        cq.exporters.export(shape.intersect(sectionbox),str(OUT/(name+'.stl')))
    def at(name,x,y):
        m=trimesh.load_mesh(OUT/(name+'.stl'));m.apply_translation((x,y,0));return m
    plate=[at('carrier_body',-22,0),at('fit_coupon',12,-11)]
    for x,y in [(11,3),(21,3),(11,13),(21,13),(23,-11)]:plate.append(at('rear_cap_print_4',x,y))
    for name,parts,count in [('prototype_plate',plate,7),('fit_test_plate',[at('fit_coupon',0,0),at('rear_cap_print_4',13,0)],2)]:
        m=trimesh.util.concatenate(parts);m.export(OUT/(name+'.stl'))
        assert len(m.split(only_watertight=False,repair=False))==count and m.is_watertight and m.is_winding_consistent
    (OUT/'preflight.json').write_text(json.dumps(report,indent=2))
    (OUT/'parameters.json').write_text(json.dumps(p,indent=2))
    s=OUT/'slicer';s.mkdir(exist_ok=True)
    for name in ['machine','process','filament']:shutil.copy2(ROOT/'prototype-pla-v4/slicer'/(name+'.json'),s/(name+'.json'))
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
