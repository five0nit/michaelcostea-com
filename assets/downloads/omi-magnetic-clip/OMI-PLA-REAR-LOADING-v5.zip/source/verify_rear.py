"""Verify v5 exported assembly and exact embedded Bambu extrusion paths."""
from pathlib import Path
import json,re,zipfile,math,xml.etree.ElementTree as ET
import numpy as np
import trimesh

ROOT=Path(__file__).resolve().parent;P=ROOT/'prototype-pla-v5'
r=json.loads((P/'preflight.json').read_text());p=r['parameters'];reports={}
ns={'c':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}

def parse(g):
 layer=0;x=y=None;width=.42;feature='';zheight=0;layers={}
 for line in g.splitlines():
  m=re.match(r'; layer num/total_layer_count: (\d+)/(\d+)',line)
  if m:layer=int(m[1]);layers[layer]={'declared':int(m[2]),'segments':[],'z':zheight};continue
  if line.startswith('; Z_HEIGHT:'):zheight=float(line.split(':')[1]);continue
  if line.startswith('; LINE_WIDTH:'):width=float(line.split(':')[1]);continue
  if line.startswith('; FEATURE:'):feature=line.split(':')[1].strip();continue
  if not re.match(r'^G[0123]\s',line):continue
  v={k:float(t) for k,t in re.findall(r'\b([XYE])(-?[\d.]+)',line)};nx=v.get('X',x);ny=v.get('Y',y)
  if layer and None not in (x,y,nx,ny) and v.get('E',0)>0 and (x!=nx or y!=ny):
   assert line.startswith('G1 ')
   layers[layer]['segments'].append((x,y,nx,ny,width,feature))
  x,y=nx,ny
 return layers

for name in ['OMI_PLA_FIT_TEST','OMI_PLA_PROTOTYPE']:
 with zipfile.ZipFile(P/'slicer'/name/(name+'.3mf')) as z:
  assert z.testzip() is None
  cfg=json.loads(z.read('Metadata/project_settings.config'));g=z.read('Metadata/plate_1.gcode').decode()
  info=ET.fromstring(z.read('Metadata/slice_info.config'))
  model=ET.fromstring(z.read('3D/3dmodel.model'))
  mesh=ET.fromstring(z.read('3D/Objects/object_1.model'))
  config=ET.fromstring(z.read('Metadata/model_settings.config'))
 assert (P/'slicer'/name/'plate_1.gcode').read_text()==g
 expected={'printer_model':'Bambu Lab A1 mini','nozzle_diameter':['0.4'],'filament_type':['PLA'],'layer_height':'0.16','initial_layer_print_height':'0.16','enable_support':'0','enable_arc_fitting':'0','wall_loops':'4','curr_bed_type':'Textured PEI Plate'}
 for k,v in expected.items():assert cfg[k]==v,(name,k,cfg[k])
 for k in ['machine_start_gcode','machine_end_gcode','layer_change_gcode','time_lapse_gcode','change_filament_gcode']:
  f=Path('/mnt/c/Program Files/Bambu Studio/resources/profiles/BBL/machine')/f'Bambu Lab A1 mini 0.4 nozzle template {k}.json'
  assert cfg[k]==json.loads(f.read_text())[k]
 assert 'M83' in g and 'M109 S220' in g and 'M190 S65' in g
 layers=parse(g);emitted=sorted(layers);declared=layers[emitted[-1]]['declared']
 assert emitted==list(range(1,len(emitted)+1))
 empty=[]
 for node in info.findall('.//layer_filament_list'):
  if not node.get('filament_list','').strip():
   lo,hi=map(int,node.get('layer_ranges').split());empty.extend(range(lo+1,hi+2))
 assert set(range(1,declared+1))-set(emitted)==set(empty)
 assert emitted[-1]==43 and empty==[44]
 t=re.search(r'model printing time: ([^;]+); total estimated time: ([^\n]+)',g)
 item=model.find('.//c:item',ns);trans=np.array(list(map(float,item.get('transform').split()))).reshape(4,3)
 assert np.allclose(trans[:3]@trans[:3].T,np.eye(3),atol=1e-6) and np.allclose(trans[2],[0,0,1],atol=1e-6),'Unexpected print reorientation'
 if 'FIT' in name:assert np.allclose(trans[:3],np.eye(3))
 offset=trans[3]
 component=model.find('.//c:component',ns);ct=np.array(list(map(float,component.get('transform').split()))).reshape(4,3)
 verts=np.array([[float(v.get(k)) for k in ['x','y','z']] for v in mesh.findall('.//c:vertex',ns)])+ct[3]
 faces=np.array([[int(v.get(k)) for k in ['v1','v2','v3']] for v in mesh.findall('.//c:triangle',ns)])
 archived=trimesh.Trimesh(vertices=verts,faces=faces,process=True)
 src='fit_test_plate' if 'FIT' in name else 'prototype_plate';count=2 if 'FIT' in name else 7
 original=trimesh.load_mesh(P/(src+'.stl'))
 assert np.allclose(archived.bounds,original.bounds,atol=1e-5)
 assert archived.is_watertight and archived.is_winding_consistent and len(archived.split(only_watertight=False,repair=False))==count
 stats=config.find('.//mesh_stat').attrib
 assert all(int(v)==0 for k,v in stats.items() if k!='face_count')
 report={**expected,'templates_match_installed':True,'no_mesh_repairs':stats,'mesh_components':count,'embedded_mesh_matches_source_bounds':True,'extruded_layers':len(emitted),'declared_layers':declared,'empty_tail_layers':empty,'final_extruded_z_mm':layers[emitted[-1]]['z'],'model_print_time':t[1],'total_estimated_time':t[2],'filament_grams':float(re.search(r'total filament weight \[g\] : ([\d.]+)',g)[1]),'slicer_warnings':[n.attrib for n in info.findall('.//warning')]}
 reports[name]=report
 if 'FIT' in name:
  # Direct geometric coverage at 360 positions around the functional inner lip.
  # Derive coupon-to-plate translation from 3MF, never eyeball rendered pixels.
  def covers(segments,xy):
   for ax,ay,bx,by,w,kind in segments:
    dx,dy=bx-ax,by-ay;t=max(0,min(1,((xy[0]-ax)*dx+(xy[1]-ay)*dy)/(dx*dx+dy*dy)))
    if math.hypot(xy[0]-ax-t*dx,xy[1]-ay-t*dy)<=w/2+.015:return True
   return False
  a=math.radians(p['tilt_deg']);ph=math.radians(p['phase_deg'])
  length=p['floor']+p['magnet_height']+p['axial_clearance']+p['cap_lip']
  origin_z=p['wrapper_center_z']-(p['wrapper_minor']+p['fabric_gap']+length)*math.cos(a)
  samples=[];radius=1.90;localz=4.10+p['front_gap']+p['front_lip']/2
  for degrees in range(0,360):
   theta=math.radians(degrees);lx=radius*math.cos(theta);ly=radius*math.sin(theta)
   xx=lx*math.cos(a)-localz*math.sin(a);yy=ly
   xy=[xx*math.cos(ph)-yy*math.sin(ph)+offset[0],xx*math.sin(ph)+yy*math.cos(ph)+offset[1]]
   midz=origin_z+lx*math.sin(a)+localz*math.cos(a)
   expected_layers=[n for n,l in layers.items() if abs(l['z']-.08-midz)<=p['front_lip']/math.cos(a)/2+1e-4]
   covered=[n for n in expected_layers if covers(layers[n]['segments'],xy)]
   samples.append({'angle_deg':degrees,'sample_xy_mm':xy,'expected_layers':expected_layers,'covered_layers':covered})
  counts=[len(s['covered_layers']) for s in samples]
  lip={'sample_count':len(samples),'sample_radius_mm':radius,'normal_lip_thickness_mm':p['front_lip'],'nominal_layer_height_mm':.16,'tilt_deg':p['tilt_deg'],'samples':samples,'all_expected_sample_layers_covered':all(s['covered_layers']==s['expected_layers'] for s in samples),'every_angular_sample_has_retaining_material':min(counts)>0,'covered_layer_count_histogram':{str(n):counts.count(n) for n in sorted(set(counts))},'interpretation':'Extrusion-width footprint coverage at inner retaining edge, not physical print/strength validation. Inclined 0.32mm lip is quantized: nominal two-layer thickness does not guarantee exactly two extrusions at every XY position. Full CAD-layer coverage is reported separately, not claimed.'}
  (P/'front-lip-toolpath-check.json').write_text(json.dumps(lip,indent=2))
  print('LIP',json.dumps(lip,indent=2))
  assert lip['every_angular_sample_has_retaining_material'],'Actual thin-lip toolpaths have a missing angular retaining segment'
# Direct magnet mesh centroid comparison across old/new references.
centres={}
for version in ['v4','v5']:
 m=trimesh.load_mesh(ROOT/('prototype-pla-'+version)/'reference_magnets.stl')
 parts=m.split(only_watertight=False,repair=False);assert len(parts)==4
 centres[version]=sorted([[float(math.atan2(c.center_mass[1],c.center_mass[0])),float(np.linalg.norm(c.center_mass[:2])),float(c.center_mass[2])] for c in parts])
delta=[b[1]-a[1] for a,b in zip(centres['v4'],centres['v5'])];assert max(map(abs,delta))<1e-4
# Explain final empty sloped outside tip separately from functional inner lip.
top=trimesh.load_mesh(P/'carrier_body.stl');sec=top.section(plane_origin=[0,0,6.96],plane_normal=[0,0,1]);extents=[]
for contour in sec.discrete:
 xy=contour[:,:2];_,_,v=np.linalg.svd(xy-xy.mean(axis=0),full_matrices=False);dims=np.ptp((xy-xy.mean(axis=0))@v.T,axis=0);extents.append(sorted(map(float,dims)))
assert all(x[0]<.25 for x in extents)
final={'slices':reports,'magnet_centres':centres,'magnet_radial_change_v4_to_v5_mm':delta,'empty_tail_cross_section_plane_z':6.96,'empty_tail_contour_principal_extents_mm':extents,'front_lip_toolpath_check_pass':True,'physical_print_tested':False,'printer_dispatch':False}
(P/'verification.json').write_text(json.dumps(final,indent=2));print(json.dumps(final,indent=2))
