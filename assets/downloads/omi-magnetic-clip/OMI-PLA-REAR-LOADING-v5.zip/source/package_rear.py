"""Package v5 rear-loading prototype, exact source inputs, renders and receipts."""
from pathlib import Path
import json,hashlib,zipfile,math
from PIL import Image,ImageDraw,ImageFont,ImageOps
ROOT=Path(__file__).resolve().parent;P=ROOT/'prototype-pla-v5'
g=json.loads((P/'preflight.json').read_text());p=g['parameters'];v=json.loads((P/'verification.json').read_text());lip=json.loads((P/'front-lip-toolpath-check.json').read_text())
a=v['slices']['OMI_PLA_FIT_TEST'];b=v['slices']['OMI_PLA_PROTOTYPE'];height=g['parts']['carrier_body']['extent_mm'][2]
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
f=lambda n,b=False:ImageFont.truetype(bold if b else font,n)
board=Image.new('RGB',(1600,1200),'#101923');d=ImageDraw.Draw(board)
d.text((45,30),'OMI / REAR-LOADING / V5',font=f(42,True),fill='white')
d.text((45,91),'Thin contact face. Screw caps behind the magnets.',font=f(28),fill='#abc8d2')
for x,file,label in [(40,'front.png','FRONT / INTEGRAL RETAINING LIPS'),(815,'rear-exploded.png','BACK / REMOVABLE SCREW CUPS')]:
 im=ImageOps.contain(Image.open(P/file).convert('RGB'),(745,560));board.paste(im,(x+(745-im.width)//2,160+(560-im.height)//2));d.text((x+6,746),label,font=f(24,True),fill='white')
d.line((45,804,1555,804),fill='#38515e',width=2)
im=ImageOps.contain(Image.open(P/'section.png').convert('RGB'),(500,300));board.paste(im,(45,835))
d.text((60,1148),'CUTAWAY / CONTACT SIDE AT TOP',font=f(20,True),fill='#abc8d2')
lines=[('0.32 mm front retaining lip',31,True),('Ø3.50 mm opening / Ø5.30 mm magnet bore',25,False),('15° tilt and inward magnet spacing retained',24,False),(f'Ring Ø{2*p["base_radius"]:.2f} mm / overall height {height:.2f} mm',24,False),('Rear screwdriver slots; no screw heads on front',24,False),('Inclined lip: sliced thickness varies locally.',23,False),('Fit prototype. Physical retention / holding untested.',22,False)]
y=845
for text,size,boldflag in lines:d.text((590,y),text,font=f(size,boldflag),fill='white' if boldflag else '#abc8d2');y+=44
afile=P/'OMI_REAR_LOADING_PREVIEW.png';board.save(afile)
qa=Image.new('RGB',(1440,1040),'#101923');qd=ImageDraw.Draw(qa)
qd.text((25,20),'V5 / ACTUAL EXTRUSION PATHS / REAR-LOADING FIT TEST',font=f(27,True),fill='white')
for i,n in enumerate([1,3,8,20,31,35,38,43]):
 x=20+i%4*355;y=80+i//4*480
 im=ImageOps.contain(Image.open(P/'toolpaths-fit'/f'layer_{n:02d}_toolpath.png').convert('RGB'),(335,400))
 qa.paste(im,(x,y+45));qd.text((x+5,y),f'LAYER {n}',font=f(23,True),fill='white')
qa.save(P/'OMI_REAR_LOADING_TOOLPATHS.png')
readme=f'''# Omi rear-loading PLA carrier — fit prototype v5

## Requested change
Magnets and matching screw cups now insert **from behind**. The contact-facing retaining lip is integral with the body; no cap/flange sits on the device-facing surface. “Battery” in the request was interpreted as the four salvaged retail-box magnets, not a request to modify the Omi battery.

- Front lip **0.32 mm normal thickness**, opening **Ø3.50 mm**.
- Estimated magnet remains **Ø4 × 3 mm**; bore remains **Ø5.30 mm** after the requested +1mm diameter correction.
- Magnet face sits **0.37 mm** behind the front surface: 0.32mm lip +0.05mm axial gap, versus v4 0.42mm. Rear loading removes front hardware; it does not remove the retaining lip or prove stronger magnetic holding.
- All four actual magnet centres retain the v4 **9.250mm radial position**, exactly1mm inward from v3; **15° tilt retained**. Direct exported-mesh centroid comparison verified.
- Ring **Ø{2*p['base_radius']:.2f} mm** (v4 Ø29.19mm), 0.35mm inside pod radial tips. Main frame remains 1.60mm thick; only the contact retaining lips are 0.32mm.
- Rear screw head **0.96mm** thick with a **0.32mm-deep** screwdriver slot, leaving 0.64mm nominal backing below slot. Root wall0.80mm, pod thread wall1.05mm, pitch1.40mm, engagement2turns.
- **Overall CAD height {height:.2f}mm** (v4 assembly6.33mm). This is a cleaner contact side, NOT a thinner overall assembly: rear head clearance required raising seats about0.50mm, and the new outer roof edge changes the height envelope. Rear heads stay at least0.25mm above the frame's flat rear plane.

Use **matching v5 body and rear cups**. Do not combine with v4 front retainers. Previous packages remain unchanged.

## Layer count: measured, not assumed
The integral lips remain tilted15°. 0.32mm is two nominal0.16mm layers of material, **not exactly two horizontal extrusion layers at every XY location**. Exact fit-plate G-code, sampled at360 angular positions at radius1.90mm on the functional inner retaining edge:
- {lip['covered_layer_count_histogram'].get('1',0)} sampled positions have one covered nominal layer.
- {lip['covered_layer_count_histogram'].get('2',0)} have two.
- {lip['covered_layer_count_histogram'].get('3',0)} have three due to the angled-layer intersection.
- All360 have retaining-material paths. Full ideal-CAD-layer coverage is **false**; some edge portions are locally reduced by slicing. This is deliberately reported rather than falsely labelling the whole face an exact two-layer print.

The inner ring is a short unsupported overhang. Generated no-support toolpaths and coverage do not demonstrate real PLA bridging or strength. Print the faithful coupon first and check the lip survives handling. A strict uniform two-horizontal-layer contact face would require changing the15° geometry or splitting/reorienting the pods; neither silently done here.

## Print and fit test
Prepared Bambu3MFs target **A1 mini / 0.4mm nozzle / PLA / Textured PEI**; printer ownership is not assumed. Other machine: reslice supplied STLs with its profile. Initial and subsequent layers0.16mm, requested4walls,6top/bottom layers,25%gyroid,220°C nozzle/65°C bed, supports off, brim off, arc fitting off. STL orientation is intentional: rear frame plane on bed, contact faces up; screw cups head-down with barrels up. Do not auto-orient the cups onto their threaded side.

**Fit plate:** cropped actual angled body socket + one rear screw cup; estimate **{a['total_estimated_time']}**, **{a['filament_grams']:.2f}g PLA**, including preparation. Model-only printing {a['model_print_time']}.

1. Print `OMI_PLA_FIT_TEST.3mf` or reslice `models/fit_test_plate.stl` for the correct printer.
2. Inspect the integral front lip and rear thread roots. Test the empty cup gently from the rear; loosen/remove any stringing rather than force threads.
3. Test actual magnet fit in the Ø5.30mm cup bore. Put the magnet into the cup's open threaded end with the desired pole toward the front opening. Insert loaded cup from behind the body, magnet-first, then tighten gently using the rear slot.
4. Check the front lip retains the magnet despite lateral bore play, the rear cup seats without binding, and the cup does not loosen during handling. Do not torque the rear plug against the thin lip; this is an estimated-dimension prototype with0.10mm rear and0.05mm front axial space.
5. After coupon passes, print full carrier plus four matching cups. Preserve working cardboard polarity and test shirt/device holding over a soft surface.

**Full prototype plate:** one body + four cups + spare/test cup + coupon =7parts. Estimate **{b['total_estimated_time']}**, **{b['filament_grams']:.2f}g PLA**. No printer job dispatched.

## Verified / pending
Verified: single connected valid BRep per printable part; raw watertight consistent STL meshes; actual assembled body/cap/magnet clearance; rear loaded-magnet withdrawal and screw motion at8positions; Ø5.28mm clearance probe; rear driver access; reference-envelope nonintersection; unchanged magnet-centre radii; real embedded3MF settings/startup templates; no mesh repairs;2/7plate components; selected actual root/face paths; quantitative lip coverage.

Both slices contain43extruded layers, lastZ6.88mm. Slicer initially declares44then explicitly marks layer44empty. CAD section atZ6.96mm consists of outer-tip crescents narrower than0.18mm; these are sub-nozzle outer-edge remnants, not an omitted whole functional contact lip. Model CAD reaches7.00mm. Known installed-profile notices retained in `evidence/verification.json`: bed-temperature and traditional-timelapse notices. No silent warning removal.

**Pending:** physical print quality, bridging, actual magnet dimensions, thread fit, lip/cup retention, polarity and magnetic holding. Digital checks do not certify those.

## Files and source
- `models/carrier_body.stl`, `models/rear_cap_print_4.stl` (ONE cup; print4), `models/fit_coupon.stl`.
- `models/fit_test_plate.stl`, `models/prototype_plate.stl` preserve print layout.
- `cad/*.step`; reference assembly contains estimated magnets and is NOT for printing.
- `source/build_rear.py`, supporting canonical generator and required v4 input snapshots. In extracted `source/`, run:
```
uv run --no-project --with cadquery==2.8.0 --with trimesh --with networkx python build_rear.py
```
- `source/slice_pla.py --version v5` requires this machine's Bambu Studio installation; rendering uses Blender. `verify_rear.py` also reads installed Bambu templates. No portability claim for machine-specific helpers.
- `evidence/preflight.json` includes legacy v4 placement datums (`floor`, `cap_lip`, `cavity_floor_z_lower_bound`); those are **not** a claim of a solid rear floor in this open-backed design. Current physical features use `front_lip`, `rear_head_thickness`, `front_gap` and rear geometry checks.

Base selection: selective reuse of canonical v4 generator and CadQuery2.8.0 library. Fresh discovery `/tmp/brief2ship-preflight-omi-rear-t6umw5nq/discovery.json` exited5/inconclusive: local loose-script scanner returnedempty and CadQuery license text did not normalize. Direct file/source inspection resolved local base and actual Apache2.0 license. Other leads were unrelated AI-assurance packages and rejected. Static inspected CadQuery repository commit c11b3f93278bb25053991f7071451f71664c90fc; no candidate code executed. Full receipt and base decision included. Upstream tests not run; local CAD and export checks are separate.

References: https://github.com/BasedHardware/omi and https://docs.omi.me/doc/hardware/consumer/mechanical . MIT notice included; device envelope remains a reference, not guaranteed device fit. No app, gateway or printer runtime settings changed.
'''
(P/'README.md').write_text(readme)
files={P/'README.md':'README.md',afile:afile.name,P/'OMI_REAR_LOADING_TOOLPATHS.png':'OMI_REAR_LOADING_TOOLPATHS.png',ROOT/'upstream/LICENSE':'licenses/BasedHardware-MIT.txt',ROOT/'REAR-LOADING-BASE-DECISION.md':'evidence/BASE-DECISION.md'}
for n in ['carrier_body','rear_cap_print_4','fit_coupon','fit_test_plate','prototype_plate']:files[P/(n+'.stl')]='models/'+n+'.stl'
for n in ['carrier_body','rear_cap_print_4','fit_coupon','assembly_reference_not_for_print']:files[P/(n+'.step')]='cad/'+n+'.step'
for n in ['build_rear.py','build_prototype.py','slice_pla.py','render_rear.py','verify_rear.py','package_rear.py']:files[ROOT/n]='source/'+n
for n in ['preflight.json','reference_magnets.stl']:files[ROOT/'prototype-pla-v4'/n]='source/prototype-pla-v4/'+n
for n in ['machine','process','filament']:
 files[ROOT/'prototype-pla-v4/slicer'/(n+'.json')]='source/prototype-pla-v4/slicer/'+n+'.json'
 files[P/'slicer'/(n+'.json')]='profiles/'+n+'.json'
for title in v['slices']:files[P/'slicer'/title/(title+'.3mf')]=title+'.3mf'
for n in ['preflight.json','parameters.json','verification.json','front-lip-toolpath-check.json']:files[P/n]='evidence/'+n
for n in ['discovery.json','discovery.md']:files[Path('/tmp/brief2ship-preflight-omi-rear-t6umw5nq')/n]='evidence/discovery/'+n
files[Path('/tmp/brief2ship-preflight-omi-rear-t6umw5nq/worktrees/cadquery-6c6db30cba74/LICENSE')]='licenses/CadQuery-Apache-2.0.txt'
archive=ROOT/'OMI-PLA-REAR-LOADING-v5.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for src,dest in files.items():z.write(src,dest)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)
 assert set(z.namelist())==set(files.values())
 for src,dest in files.items():assert z.read(dest)==src.read_bytes(),dest
receipt={'archive':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(files),'zip_integrity_pass':True,'all_archived_files_match_sources':True,'slices':v['slices'],'front_lip':'0.32mm normal; quantized inclined paths, NOT uniform two layers','physical_print_tested':False,'printer_dispatch':False}
(P/'delivery-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
