# Omi rear-loading PLA carrier — fit prototype v5

## Requested change
Magnets and matching screw cups now insert **from behind**. The contact-facing retaining lip is integral with the body; no cap/flange sits on the device-facing surface. “Battery” in the request was interpreted as the four salvaged retail-box magnets, not a request to modify the Omi battery.

- Front lip **0.32 mm normal thickness**, opening **Ø3.50 mm**.
- Estimated magnet remains **Ø4 × 3 mm**; bore remains **Ø5.30 mm** after the requested +1mm diameter correction.
- Magnet face sits **0.37 mm** behind the front surface: 0.32mm lip +0.05mm axial gap, versus v4 0.42mm. Rear loading removes front hardware; it does not remove the retaining lip or prove stronger magnetic holding.
- All four actual magnet centres retain the v4 **9.250mm radial position**, exactly1mm inward from v3; **15° tilt retained**. Direct exported-mesh centroid comparison verified.
- Ring **Ø28.67 mm** (v4 Ø29.19mm), 0.35mm inside pod radial tips. Main frame remains 1.60mm thick; only the contact retaining lips are 0.32mm.
- Rear screw head **0.96mm** thick with a **0.32mm-deep** screwdriver slot, leaving 0.64mm nominal backing below slot. Root wall0.80mm, pod thread wall1.05mm, pitch1.40mm, engagement2turns.
- **Overall CAD height 7.00mm** (v4 assembly6.33mm). This is a cleaner contact side, NOT a thinner overall assembly: rear head clearance required raising seats about0.50mm, and the new outer roof edge changes the height envelope. Rear heads stay at least0.25mm above the frame's flat rear plane.

Use **matching v5 body and rear cups**. Do not combine with v4 front retainers. Previous packages remain unchanged.

## Layer count: measured, not assumed
The integral lips remain tilted15°. 0.32mm is two nominal0.16mm layers of material, **not exactly two horizontal extrusion layers at every XY location**. Exact fit-plate G-code, sampled at360 angular positions at radius1.90mm on the functional inner retaining edge:
- 63 sampled positions have one covered nominal layer.
- 291 have two.
- 6 have three due to the angled-layer intersection.
- All360 have retaining-material paths. Full ideal-CAD-layer coverage is **false**; some edge portions are locally reduced by slicing. This is deliberately reported rather than falsely labelling the whole face an exact two-layer print.

The inner ring is a short unsupported overhang. Generated no-support toolpaths and coverage do not demonstrate real PLA bridging or strength. Print the faithful coupon first and check the lip survives handling. A strict uniform two-horizontal-layer contact face would require changing the15° geometry or splitting/reorienting the pods; neither silently done here.

## Print and fit test
Prepared Bambu3MFs target **A1 mini / 0.4mm nozzle / PLA / Textured PEI**; printer ownership is not assumed. Other machine: reslice supplied STLs with its profile. Initial and subsequent layers0.16mm, requested4walls,6top/bottom layers,25%gyroid,220°C nozzle/65°C bed, supports off, brim off, arc fitting off. STL orientation is intentional: rear frame plane on bed, contact faces up; screw cups head-down with barrels up. Do not auto-orient the cups onto their threaded side.

**Fit plate:** cropped actual angled body socket + one rear screw cup; estimate **13m 11s**, **0.45g PLA**, including preparation. Model-only printing 5m 30s.

1. Print `OMI_PLA_FIT_TEST.3mf` or reslice `models/fit_test_plate.stl` for the correct printer.
2. Inspect the integral front lip and rear thread roots. Test the empty cup gently from the rear; loosen/remove any stringing rather than force threads.
3. Test actual magnet fit in the Ø5.30mm cup bore. Put the magnet into the cup's open threaded end with the desired pole toward the front opening. Insert loaded cup from behind the body, magnet-first, then tighten gently using the rear slot.
4. Check the front lip retains the magnet despite lateral bore play, the rear cup seats without binding, and the cup does not loosen during handling. Do not torque the rear plug against the thin lip; this is an estimated-dimension prototype with0.10mm rear and0.05mm front axial space.
5. After coupon passes, print full carrier plus four matching cups. Preserve working cardboard polarity and test shirt/device holding over a soft surface.

**Full prototype plate:** one body + four cups + spare/test cup + coupon =7parts. Estimate **28m 3s**, **2.21g PLA**. No printer job dispatched.

## Verified / pending
Verified: single connected valid BRep per printable part; raw watertight consistent STL meshes; actual assembled body/cap/magnet clearance; rear loaded-magnet withdrawal and screw motion at8positions; Ø5.28mm clearance probe; rear driver access; reference-envelope nonintersection; unchanged magnet-centre radii; real embedded3MF settings/startup templates; no mesh repairs;2/7plate components; selected actual root/face paths; quantitative lip coverage.

Both slices contain43extruded layers, lastZ6.88mm. Slicer initially declares44then explicitly marks layer44empty. CAD section atZ6.96mm consists of outer-tip crescents narrower than0.18mm; these are sub-nozzle outer-edge remnants, not an omitted whole functional contact lip. Model CAD reaches7.00mm. Known installed-profile notices retained in `evidence/verification.json`: bed-temperature and traditional-timelapse notices. No silent warning removal.

**Pending:** physical print quality, bridging, actual magnet dimensions, thread fit, lip/cup retention, polarity and magnetic holding. Digital checks do not certify those.

## Files and source
- `models/carrier_body.stl`, `models/rear_cap_print_4.stl` (ONE cup; print4), `models/fit_coupon.stl`.
- `models/fit_test_plate.stl`, `models/prototype_plate.stl` preserve print layout.
- `cad/*.step`; reference assembly contains estimated magnets and is NOT for printing.
- `source/build_rear.py`, supporting canonical generator and required v4 input snapshots. In extracted `source/`, run:
```
uv run --no-project --with cadquery==2.8.0 --with trimesh --with networkx python build_rear.py
```
- `source/slice_pla.py --version v5` requires this machine's Bambu Studio installation; rendering uses Blender. `verify_rear.py` also reads installed Bambu templates. No portability claim for machine-specific helpers.
- `evidence/preflight.json` includes legacy v4 placement datums (`floor`, `cap_lip`, `cavity_floor_z_lower_bound`); those are **not** a claim of a solid rear floor in this open-backed design. Current physical features use `front_lip`, `rear_head_thickness`, `front_gap` and rear geometry checks.

Base selection: selective reuse of canonical v4 generator and CadQuery2.8.0 library. Fresh discovery `/tmp/brief2ship-preflight-omi-rear-t6umw5nq/discovery.json` exited5/inconclusive: local loose-script scanner returnedempty and CadQuery license text did not normalize. Direct file/source inspection resolved local base and actual Apache2.0 license. Other leads were unrelated AI-assurance packages and rejected. Static inspected CadQuery repository commit c11b3f93278bb25053991f7071451f71664c90fc; no candidate code executed. Full receipt and base decision included. Upstream tests not run; local CAD and export checks are separate.

References: https://github.com/BasedHardware/omi and https://docs.omi.me/doc/hardware/consumer/mechanical . MIT notice included; device envelope remains a reference, not guaranteed device fit. No app, gateway or printer runtime settings changed.
