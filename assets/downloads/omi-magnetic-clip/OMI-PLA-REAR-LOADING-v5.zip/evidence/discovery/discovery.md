# Brief2Ship code-discovery receipt

## Decision

- Overall: `inconclusive`
- Decision status: `inconclusive`
- Discovery status: `partial`
- Selected candidate: `none; shortlist entries are leads`
- Reason: `source collection incomplete; reuse/build decision deferred`
- Query: `CadQuery parametric threaded magnet holder rear loading PLA`
- Started: `2026-10-02T06:50:01.683758+00:00`
- Completed: `2026-10-02T06:50:16.845839+00:00`
- Displayed / evaluated candidates: 3 / 3
- Core query: `CadQuery parametric threaded magnet holder rear loading PLA`
- Requested constraints: `none extracted`
- Incomplete evidence: `local: empty`

## Ranked candidates

| # | Score | Decision score | Coverage | Candidate | Source | Feature | Activity | Dependencies | Security | Tests | Portability | Reuse | Adoption | Recommendation | Status |
|---:|---:|---:|---:|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| 1 | 72.00 | 69.97 | 0.90 | `cadquery` | `pypi` | 9.00 | 15.00 | 7.00 | 10.00 | 9.00 | 8.00 | 9.00 | 5.00 | `reject` | `blocked` |
| 2 | 60.19 | 58.16 | 0.90 | `aiq-magnet` | `pypi` | 3.00 | 15.00 | 5.00 | 10.00 | 9.00 | 8.00 | 9.00 | 1.19 | `reject` | `blocked` |
| 3 | 50.75 | 42.44 | 0.47 | `aiq-magnet-theory` | `pypi` | 2.25 | 15.00 | 5.00 | 11.00 | 3.00 | 8.00 | 5.00 | 1.50 | `reject` | `blocked` |

## Inspection allocation

- `cadquery`: `slot 1: observed blockers last, feature fit 7.25/25, then confidence-adjusted score`; status=`inspected`
- `aiq-magnet`: `slot 2: observed blockers last, feature fit 2.25/25, then confidence-adjusted score`; status=`inspected`

## Candidate evidence

### 1. `cadquery`

- URL: `https://pypi.org/project/cadquery/`
- Repository: `https://github.com/CadQuery/cadquery`
- Local path: `not local`
- Homepage/demo: `https://cadquery.org`
- Version: `2.8.0`
- Canonical identity: `pypi:cadquery@2.8.0`
- License: `Apache Public License 2.0`
- Normalized license: `unknown`
- Requested constraint checks: `none`
- Requirement evidence: `[]`
- Retrieval evidence: `{"method": "bounded-name-index-and-curated-hints", "routes": ["package-name-match"], "query": "CadQuery parametric threaded magnet holder rear loading PLA", "metadata_url": "https://pypi.org/pypi/cadquery/json", "hydration_budget": 9, "hydration_shortlist_count": 9, "query_terms": ["cadquery", "holder", "loading", "magnet", "parametric", "pla", "rear", "threaded"], "ignored_query_terms": [], "matched_terms": {"name": ["cadquery"], "summary": ["cadquery", "parametric"], "keywords": [], "description": ["cadquery", "parametric"]}, "rank_basis": {"exact_name": 0, "term_coverage": 2, "weighted_matches": 9, "weights": {"name": 3, "summary_or_keywords": 2, "description": 1}}, "description_characters_considered": 12448, "supporting_excerpts": {"summary": ["CadQuery is a parametric  scripting language for creating and traversing CAD models"], "keywords": [], "description": ["![CadQuery logo](./doc/_static/logo/cadquery_logo_dark.svg)\r\n# CadQuery\r\n\r\n[![Appveyor Build status](https://ci.appveyor.com/api/projects/stat", ")\r\n\r\n---\r\n\r\n## What is CadQuery\r\n\r\nCadQuery is an intuitive, easy-to-use Python module for building parametric 3D CAD models. Using CadQuery, you can write short, simple scripts that produce high quality CAD models. It is easy to make many "]}}`
- Activity: `2026-09-25T03:56:52Z`
- Dependencies: `13`
- Stars / forks / watchers: `5868 / 548 / 72`
- Contributors / open issues: `119 / 439 (issue-only)`
- Vulnerabilities: `none observed`
- Recommendation: `reject`
- Recommendation status: `blocked`
- Hard blockers: `license is outside the default permissive allowlist`
- Required checks: `verify package-specific source, tests and license; static inspection covers the repository, not a proven package subtree; authorized sandbox test pass unavailable`
- Inspection: `inspected`
- Clone: `/tmp/brief2ship-preflight-omi-rear-t6umw5nq/worktrees/cadquery-6c6db30cba74`
- Commit: `c11b3f93278bb25053991f7071451f71664c90fc`
- Manifests: `setup.cfg, setup.py`
- Test files: `33`
- CI files: `2`

Score evidence:

- `feature_match`: `core relevance query=CadQuery parametric threaded magnet holder rear loading PLA; name token coverage=0.12; description token coverage=0.25; topic token coverage=0.25; exact phrase bonus=0; candidate identity bonus=4; evidence coverage=1.00`
- `maintenance_activity`: `last activity 7 days ago; evidence coverage=1.00`
- `dependency_weight`: `declared dependencies=13; evidence coverage=1.00`
- `security_posture`: `OSV findings=0; license requires review=Apache Public License 2.0; security policy absent; evidence coverage=0.75`
- `test_quality`: `test files/signals present; CI workflow present; test command detected; evidence coverage=1.00`
- `portability`: `cross-platform status not disproven; neutral baseline; portable ecosystem=Python; evidence coverage=0.40`
- `reuse_readiness`: `repository link present; description present; documentation present; examples present; package/build manifest present; bounded source footprint; evidence coverage=1.00`
- `adoption_health`: `strongest adoption signal=5868; forks=548; watchers=72; contributors=119; open issues=439; evidence coverage=1.00`
- `decision_score`: `raw total=72.00; unknown evidence cost=2.02; decision score=max(0, raw total - unknown evidence cost)=69.97`

### 2. `aiq-magnet`

- URL: `https://pypi.org/project/aiq-magnet/`
- Repository: `https://github.com/AIQ-Kitware/aiq-magnet`
- Local path: `not local`
- Homepage/demo: `unknown`
- Version: `0.1.0`
- Canonical identity: `pypi:aiq-magnet@0.1.0`
- License: `Apache 2`
- Normalized license: `unknown`
- Requested constraint checks: `none`
- Requirement evidence: `[]`
- Retrieval evidence: `{"method": "bounded-name-index-and-curated-hints", "routes": ["package-name-match"], "query": "CadQuery parametric threaded magnet holder rear loading PLA", "metadata_url": "https://pypi.org/pypi/aiq-magnet/json", "hydration_budget": 9, "hydration_shortlist_count": 9, "query_terms": ["cadquery", "holder", "loading", "magnet", "parametric", "pla", "rear", "threaded"], "ignored_query_terms": [], "matched_terms": {"name": ["magnet"], "summary": ["magnet"], "keywords": [], "description": ["magnet"]}, "rank_basis": {"exact_name": 0, "term_coverage": 1, "weighted_matches": 6, "weights": {"name": 3, "summary_or_keywords": 2, "description": 1}}, "description_characters_considered": 16384, "supporting_excerpts": {"summary": ["Kitware's MAGNET framework for AIQ"], "keywords": [], "description": ["# AIQ MAGNET \nMathematical Assurance of Generative AI Network Evaluation Toolkit\n\n## Introduction\n\nThis early version of the MAGNET package is int"]}}`
- Activity: `2026-10-01T21:13:09Z`
- Dependencies: `19`
- Stars / forks / watchers: `2 / 2 / 0`
- Contributors / open issues: `7 / 4 (issue-only)`
- Vulnerabilities: `none observed`
- Recommendation: `reject`
- Recommendation status: `blocked`
- Hard blockers: `license is outside the default permissive allowlist`
- Required checks: `verify package-specific source, tests and license; static inspection covers the repository, not a proven package subtree; authorized sandbox test pass unavailable`
- Inspection: `inspected`
- Clone: `/tmp/brief2ship-preflight-omi-rear-t6umw5nq/worktrees/aiq-magnet-92e36741ec05`
- Commit: `7bb105ab1c85bfaa01bf68c97ff7523332479ee4`
- Manifests: `pyproject.toml, requirements.lock.txt, requirements/runtime.txt, packages/aiq-magnet-theory/pyproject.toml, requirements/locks/tests-optional.txt, requirements/locks/tests.txt`
- Test files: `35`
- CI files: `3`

Score evidence:

- `feature_match`: `core relevance query=CadQuery parametric threaded magnet holder rear loading PLA; name token coverage=0.12; description token coverage=0.12; topic token coverage=0.00; exact phrase bonus=0; candidate identity bonus=0; evidence coverage=1.00`
- `maintenance_activity`: `last activity 0 days ago; evidence coverage=1.00`
- `dependency_weight`: `declared dependencies=19; evidence coverage=1.00`
- `security_posture`: `OSV findings=0; license requires review=Apache 2; security policy absent; evidence coverage=0.75`
- `test_quality`: `test files/signals present; CI workflow present; test command detected; evidence coverage=1.00`
- `portability`: `cross-platform status not disproven; neutral baseline; portable ecosystem=Python; evidence coverage=0.40`
- `reuse_readiness`: `repository link present; description present; documentation present; examples present; package/build manifest present; bounded source footprint; evidence coverage=1.00`
- `adoption_health`: `strongest adoption signal=2; forks=2; watchers=0; contributors=7; open issues=4; evidence coverage=1.00`
- `decision_score`: `raw total=60.19; unknown evidence cost=2.02; decision score=max(0, raw total - unknown evidence cost)=58.16`

### 3. `aiq-magnet-theory`

- URL: `https://pypi.org/project/aiq-magnet-theory/`
- Repository: `https://github.com/AIQ-Kitware/aiq-magnet`
- Local path: `not local`
- Homepage/demo: `unknown`
- Version: `0.1.0`
- Canonical identity: `pypi:aiq-magnet-theory@0.1.0`
- License: `Apache 2`
- Normalized license: `unknown`
- Requested constraint checks: `none`
- Requirement evidence: `[]`
- Retrieval evidence: ``{"method": "bounded-name-index-and-curated-hints", "routes": ["package-name-match"], "query": "CadQuery parametric threaded magnet holder rear loading PLA", "metadata_url": "https://pypi.org/pypi/aiq-magnet-theory/json", "hydration_budget": 9, "hydration_shortlist_count": 9, "query_terms": ["cadquery", "holder", "loading", "magnet", "parametric", "pla", "rear", "threaded"], "ignored_query_terms": [], "matched_terms": {"name": ["magnet"], "summary": ["magnet"], "keywords": [], "description": ["magnet"]}, "rank_basis": {"exact_name": 0, "term_coverage": 1, "weighted_matches": 6, "weights": {"name": 3, "summary_or_keywords": 2, "description": 1}}, "description_characters_considered": 745, "supporting_excerpts": {"summary": ["Dependency-free theory annotations for MAGNET"], "keywords": [], "description": ["# aiq-magnet-theory\n\n`aiq-magnet-theory` is the dependency-free annotation vocabulary used by MAGNET to\nconnect empirical Python code to theoretic"]}}``
- Activity: `2026-09-04T17:07:03.891795Z`
- Dependencies: `unknown`
- Stars / forks / watchers: `unknown / unknown / unknown`
- Contributors / open issues: `unknown / unknown`
- Vulnerabilities: `none observed`
- Recommendation: `reject`
- Recommendation status: `blocked`
- Hard blockers: `license is outside the default permissive allowlist`
- Required checks: `static repository inspection not completed; authorized sandbox test pass unavailable`

Score evidence:

- `feature_match`: `core relevance query=CadQuery parametric threaded magnet holder rear loading PLA; name token coverage=0.12; description token coverage=0.12; topic token coverage=0.00; exact phrase bonus=0; candidate identity bonus=0; evidence coverage=0.65`
- `maintenance_activity`: `last activity 27 days ago; evidence coverage=1.00`
- `dependency_weight`: `dependency count unknown; neutral score; evidence coverage=0.00`
- `security_posture`: `OSV findings=0; license requires review=Apache 2; security policy unknown; evidence coverage=0.60`
- `test_quality`: `test evidence unknown; partial neutral score; evidence coverage=0.00`
- `portability`: `cross-platform status not disproven; neutral baseline; portable ecosystem=Python; evidence coverage=0.40`
- `reuse_readiness`: `repository link present; description present; registry reuse signals=2; evidence coverage=0.30`
- `adoption_health`: `adoption data unknown; partial neutral score; evidence coverage=0.00`
- `decision_score`: `raw total=50.75; unknown evidence cost=8.31; decision score=max(0, raw total - unknown evidence cost)=42.44`

## Source receipts

- `local`: status=`empty`, returned=`0`, rate-limit-remaining=`None`
  - Queries: `CadQuery parametric threaded magnet holder rear loading PLA`
- `pypi`: status=`ok`, returned=`3`, rate-limit-remaining=`None`
  - Queries: `CadQuery parametric threaded magnet holder rear loading PLA`
  - Warning: `PyPI retrieval uses observed package-name matches plus at most 6 curated hints; hydrating 9 name(s), capped at 9 JSON requests. Ranks use observed names, summaries, keywords and the first 16384 description characters; this is not full-text index search or exhaustive coverage. Limits of at least two preserve one metadata-relevant non-name hint when available, without displacing exact package names.`

## Limitations

- `JavaScript client challenges are not bypassed; PyPI uses its official Simple index`
- `local workspace discovery is read-only and bounded; receipts may contain local paths`
- `registry popularity is supporting evidence, not proof of implementation quality`
- `repository tests never execute unless both test_top and allow_untrusted_tests are set`
- `scores compare observed public metadata; missing evidence remains explicit`
