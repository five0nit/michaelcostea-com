# Rear-loading PLA carrier: v5 base decision

Target: revise canonical CadQuery Omi carrier to rear-entry screw cups, an integral 0.32 mm contact retaining lip and Ø3.50 mm opening, preserving v4 Ø5.30 mm bore, four inward magnet centres, 15° tilt and compact ring. No printer dispatch or app work.

Fresh bounded static discovery: `/tmp/brief2ship-preflight-omi-rear-t6umw5nq/discovery.json`; sources local,pypi, per-source3/limit4/inspect2/test0, no candidate execution. CLI exit5, partial/inconclusive, local scanner returned empty despite loose canonical scripts inspected directly. This is not a clean-build recommendation.

Manual candidate disposition:
- Existing `build_prototype.py` and delivered v4: **selective-reuse**, task fit 5/5 (actual bores, placement, reference surface, BRep/mesh export and screw-motion checks). Extend in separate rear-loading scripts; preserve previous archives.
- CadQuery 2.8.0, https://pypi.org/project/cadquery/, https://github.com/CadQuery/cadquery: **use-as-library**, task fit 5/5; CLI raw score72/decision69.97. Inspection commit c11b3f93278bb25053991f7071451f71664c90fc is repository inspection identity, not claimed wheel commit. Reuse pinned already exercised library. CLI license-normalization blocker requires direct LICENSE check (Apache 2.0), not ignoring real licensing limits. Upstream test suite not executed.
- aiq-magnet0.1.0 (CLI60.19) and aiq-magnet-theory0.1.0 (50.75): **reject**, task fit0/5; AI mathematical assurance framework, not mechanical magnet CAD.

Design checks required: rear cap access through base, seated collisions, threaded removal toward rear, magnet insertion from rear, integral front lip, reference-envelope clearance, shared v4 magnet centres, print-faithful coupon, raw exported mesh integrity, actual thin inclined lip and root-wall toolpaths. At retained15° tilt, 0.32mm normal wall thickness is nominally two0.16mm layers but NOT exactly two horizontal sliced layers; report actual toolpath behavior rather than repeat v4 flat-cap layer claim. Rear-entry removes bulky hardware from contact side; strength/holding benefits require real print tests.
